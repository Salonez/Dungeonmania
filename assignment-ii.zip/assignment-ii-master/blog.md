Pair blog

https://unswcse.atlassian.net/l/cp/LTbszgWb

Tyrone

https://unswcse.atlassian.net/l/cp/LHPpQCCA
https://unswcse.atlassian.net/l/cp/P7qSFEYZ

Anton
https://unswcse.atlassian.net/l/cp/BQW5BAM0
https://unswcse.atlassian.net/l/cp/7YwHExCb
https://unswcse.atlassian.net/l/cp/jSZyx1o3