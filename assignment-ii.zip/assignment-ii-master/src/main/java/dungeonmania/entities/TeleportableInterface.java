package dungeonmania.entities;

public interface TeleportableInterface {
    // this class was made to group all teleportable entitites so that we can
    // shorten the if statements for checking if something is teleportable.
    // allows for future extension in teleporting updates.
    // code smell of an overnested or statement.
}
