package dungeonmania.entities.inventory;

/**
 * A marker interface for InventoryItem
 */
public interface InventoryItem {
}
