package dungeonmania.entities.collectables;

public interface KeyFunctionality {
    public int getNumber();
}
