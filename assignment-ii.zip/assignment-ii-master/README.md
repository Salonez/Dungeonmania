You can view the assignment specification here:
https://unswcse.atlassian.net/wiki/spaces/cs2511/pages/39485441/Assignment+II+Dungeonmania